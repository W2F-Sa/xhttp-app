package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundCool = Color(0xFFF8FAFF)
val PrimaryBlue = Color(0xFF0058BC)
val PrimaryContainerBlue = Color(0xFFE8F0FE)
val OnSurfaceDark = Color(0xFF1B1B1D)
val OnSurfaceVariantMuted = Color(0xFF414755)
val TextMuted = Color(0xFF555F71)

val GreenSuccess = Color(0xFF2E7D32)
val GreenSuccessContainer = Color(0xFFE8F5E9)

val OrangeWarning = Color(0xFFE65100)
val OrangeWarningContainer = Color(0xFFFFF3E0)

val RedError = Color(0xFFC62828)
val RedErrorContainer = Color(0xFFFFEBEE)

// Glass Translucency Levels
val GlassBackground70 = Color(0xB2FFFFFF) // 70% opacity white
val GlassBackground85 = Color(0xD9FFFFFF) // 85% opacity white
val GlassBorderSpecular = Color(0x33FFFFFF) // 20% opacity white for physical specular light reflection
val GlassBorderOutline = Color(0x1F0058BC) // faint 12% primary tint border
